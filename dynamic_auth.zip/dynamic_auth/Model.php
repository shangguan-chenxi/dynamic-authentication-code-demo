<?php

class Model
{
    public $string;
    
    private $u = 'admin';
    private $p = 'admin';
    private $d;
    
    public function __construct(){
        $this->string = "";
    }
    
    public function credential_check($u, $p, $d){
        // gerenerate dynamic code
        $curr = time();
        $curr_60_s = (int)($curr / 60) * 60;
        $salt = "my_dynamic_code";
        $full_length_dynamic_code = hash("sha256", $salt.$curr_60_s);
        $this->d = substr($full_length_dynamic_code, 0, 6);
        
        //sleep(1); // prevent brute-force attack
        if ($u == $this->u && $p == $this->p && $d == $this->d){
            $this->string = "INFO -> win&love&in&mel&:)";
        }else{
            $this->string = "Oops.. Something goes wrong :(";
        }
    }
    
}