<?php
include_once("./View.php");
include_once("./Model.php");

class Controller
{
    private $view;
    private $model;
    
    public function __construct(){
        $this->model = new Model();
        $this->view = new View($this->model->string);
    }
    
    /*
      Run function:
      Output interface
      Receive data
    */
    public function run(){
        if (isset($_POST['username']) && isset($_POST['password']) && isset($_POST['accesscode'])){
            $this->model->credential_check($_POST['username'], $_POST['password'], $_POST['accesscode']);
            $this->view = new View($this->model->string);
            unset($_POST['username']);unset($_POST['password']);unset($_POST['accesscode']);
            echo $this->view->login_page();
        }else{
            echo $this->view->login_page();
        }
    }

    

/*
if (isset($_POST['Search']) && !empty($_POST['Search'])){
    // do serach and return reuslts OR not found
}
*/
}