<?php
$curr = time();
//echo '当前Unix时间戳：'.$curr.'</br>';

$curr_60_s = (int)($curr / 60) * 60;
//echo '60秒Unix时间戳：'.$curr_60_s.'</br>';

$salt = "my_dynamic_code";
$full_length_dynamic_code = hash("sha256", $salt.$curr_60_s);
$final_dynamic_code = substr($full_length_dynamic_code, 0, 6);
//echo 'SHA256全长哈希：'.$full_length_dynamic_code.'</br>';
//echo '有效动态码：'.$final_dynamic_code.'</br>';
//echo $final_dynamic_code;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
    <meta http-equiv="refresh" content="10">
    <?php echo $final_dynamic_code;?>
</body>

