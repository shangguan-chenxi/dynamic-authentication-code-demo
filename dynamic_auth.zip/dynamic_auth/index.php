<?php
include_once("./Controller.php");
$app = new Controller();
$app->run();